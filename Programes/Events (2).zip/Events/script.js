function main(){
    document.getElementById("main").src="/imgs/1.jfif";
}
function one(){
    document.getElementById("main").src="/imgs/2.jfif";
}
function two(){
    document.getElementById("main").src="/imgs3.jfif";
}
function three(){
    document.getElementById("main").src="/imgs/4.jfif";
}
function four(){
    document.getElementById("main").src="/imgs/5.jfif";
}
