function main(){
    document.getElementById("main").src="/img/1.jfif";
}
function one(){
    document.getElementById("main").src="/img/2.jfif";
}
function two(){
    document.getElementById("main").src="/img/3.jfif";
}
function three(){
    document.getElementById("main").src="/img/4.jfif";
}
function four(){
    document.getElementById("main").src="/img/5.jfif";
}
